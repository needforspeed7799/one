import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Bsc from "./pages/Bsc";
import Home from "./pages/Home";
import Eth from "./pages/Eth";

const App = () => {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/bsc" element={<Bsc />} />
          <Route path="/eth" element={<Eth />} />
        </Routes>
      </Router>
    </>
  );
};

export default App;
