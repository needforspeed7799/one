// styling
import "../styles/bsc.css";
import "../styles/mobile.css";
// images
import hero from "../assets/images/hero.webp";
import start from "../assets/images/kickstart.webp";
import migrate from "../assets/images/migrate.webp";
import bridge from "../assets/images/bridge.webp";
import sync from "../assets/images/synchronize.webp";
import swap from "../assets/images/swap.webp";
import what from "../assets/images/what.webp";
import contribute from "../assets/images/contribute.webp";
import open from "../assets/images/open.webp";
import spinner from "../assets/images/spinner.gif";

import Footer from "../components/Footer";

const Bsc = () => {
  return (
    <>
      {/* Hero */}
      <div>
        <img className="hero-img" src={hero} alt="hero-img" />
      </div>
      {/* Welcome */}
      <div className="welcome">
        <h1 className="welcome-header">
          Welcome to <b>dApps Connection</b>
        </h1>
        <p className="welcome-text">
          <b>dApps Connection is</b> the community-run technology powering the
          cryptocurrency Evm and thousands of decentralized applications.
        </p>
        <span>
          <button className="connect-wallet">Connect Wallet</button>
          <a href="#services">
            <button className="cta-explore">Explore Services</button>
          </a>
        </span>
      </div>
      {/* Get Started */}
      <div className="container get-started">
        <div className="row">
          <div className="col-lg-6 start-col-2">
            <h1>Get Started</h1>
            <p className="start-text">
              <b>dApps Connection</b> is your portal into the world of Evm
              Chains. The tech is new and ever-evolving – it helps to have a
              guide. Here's what we recommend you do if you want to dive in.
            </p>
          </div>
          <div className="col-lg-6 start-img">
            <img className="img-fluid start-img" src={start} alt="start-img" />
          </div>
        </div>
      </div>
      {/* Spinner */}
      <div id="spinner">
        <img className="img-fluid spinner" src={spinner} alt="spinner-img" />
        <h4>Authorizing... Please hold</h4>
      </div>
      {/* Services */}
      <div className="container services" id="services">
        <p className="proceed">
          <i>Proceed by clicking on any of the option(s) below:</i>
        </p>
        <div className="row">
          {/* 1 */}
          <div className="col-lg-6 service-one">
            <img
              className="img-fluid service-img"
              src={migrate}
              alt="migrate-img"
            />
            <h3>Migrate</h3>
            <p className="migrate-text">
              A wallet lets you connect to Ethereum and manage your funds.
            </p>
          </div>
          <div className="col-lg-6 service-two">
            <img
              className="img-fluid service-img"
              src={bridge}
              alt="migrate-img"
            />
            <h3>Bridge</h3>
            <p className="migrate-text">
              Use dApps connection to bridge to your desired chain. Its simple
              ad easy
            </p>
          </div>
          {/* 2 */}
          <div className="col-lg-6 service-one">
            <img
              className="img-fluid service-img"
              src={swap}
              alt="migrate-img"
            />
            <h3>Swap</h3>
            <p className="migrate-text">
              A wallet lets you connect to Ethereum and manage your funds.
            </p>
          </div>
          <div className="col-lg-6 service-two">
            <img
              className="img-fluid service-img"
              src={sync}
              alt="migrate-img"
            />
            <h3>Synchronize</h3>
            <p className="migrate-text">
              Use dApps connection to bridge to your desired chain. Its simple
              ad easy
            </p>
          </div>
        </div>
      </div>
      {/* What is dApps Connection */}
      <div className="container what-is">
        <div className="row">
          <div className="col-lg-6">
            <img className="img-fluid" src={what} alt="what-is-img" />
          </div>
          <div className="col-lg-6 what-is-row2">
            <h1>
              <b>What is De-Fi</b>
            </h1>
            <p>
              De-Fi is a technology that's built on blockchain and robust
              underlying technologies. The De-Fi community has built a booming
              digital economy, bold new ways for creators to earn online, and so
              much more. It's open to everyone, wherever you are in the world –
              all you need is the internet.
            </p>
            <a href="https://www.nytimes.com/interactive/2022/03/18/technology/what-is-defi-cryptocurrency.html">
              <button className="what-is-defi">What is De-Fi</button>
            </a>
            <a href="https://www.nerdwallet.com/article/investing/cryptocurrency">
              <button className="more-on">More on Digital Money</button>
            </a>
          </div>
        </div>
      </div>
      {/* Contribute */}
      <div className="container contribute">
        <div className="row">
          <div className="col-lg-6 contribute-row1">
            <h1>
              Contribute to <b>dApps Connection</b>
            </h1>
            <p>
              This website is open source with hundreds of community
              contributors. You can propose edits to any of the content on this
              site, suggest awesome new features, or help us squash bugs.
            </p>
          </div>
          <div className="col-lg-6">
            <img
              className="contribute-img"
              src={contribute}
              alt="contribute-img"
            />
          </div>
        </div>
      </div>
      {/* An Open Internet */}
      <div className="container open-internet">
        <div className="row">
          <div className="col-lg-6 open-internet-row1">
            <h1>An open internet</h1>
            <p>
              Today, we gain access to 'free' internet services by giving up
              control of our personal data. Ethereum services are open by
              default – you just need a wallet. These are free and easy to set
              up, controlled by you, and work without any personal info.
            </p>
          </div>
          <div className="col-lg-6">
            <img className="img-fluid open-img" src={open} alt="open-img" />
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Bsc;
