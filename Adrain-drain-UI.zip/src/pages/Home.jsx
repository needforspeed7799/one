import { Link } from "react-router-dom";
// styling
import "../styles/home.css";
import "../styles/mobile.css";

const Home = () => {
  return (
    <>
      <div className="home">
        <h1 className="dapps-h1">Dapps Connection</h1>
        <div>
          <Link to="/bsc">
            <button>Connect to BSC</button>
          </Link>
          <Link to="/eth">
            <button>Connect to ETH</button>
          </Link>
        </div>
      </div>
    </>
  );
};

export default Home;
